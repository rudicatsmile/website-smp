<?php

declare(strict_types=1);

namespace App\Filament\Resources\ClassAnnouncements\Pages;

use App\Filament\Resources\ClassAnnouncements\ClassAnnouncementResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditClassAnnouncement extends EditRecord
{
    protected static string $resource = ClassAnnouncementResource::class;

    protected function getHeaderActions(): array
    {
        return [Actions\DeleteAction::make()];
    }
}

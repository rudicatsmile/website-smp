<?php

namespace App\Filament\Resources\Users\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class UsersTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->searchable(),
                TextColumn::make('email')
                    ->label('Email address')
                    ->searchable(),
                TextColumn::make('roles.name')
                    ->label('Role')
                    ->badge()
                    ->formatStateUsing(function (string $state): string {
                        $aliases = [
                            'super_admin'   => 'Super Admin',
                            'admin'         => 'Admin',
                            'editor'        => 'Editor',
                            'contributor'   => 'Kontributor',
                            'teacher'       => 'Guru',
                            'wali_kelas'    => 'Wali Kelas',
                            'counselor'     => 'Guru BK',
                            'guru_pengampuh'=> 'Guru Tahfidz',
                            'piket'         => 'Piket',
                            'student'       => 'Siswa',
                            'parent'        => 'Orang Tua Murid',
                        ];
                        return $aliases[$state] ?? $state;
                    })
                    ->separator(','),
                TextColumn::make('email_verified_at')
                    ->dateTime()
                    ->sortable(),
                IconColumn::make('is_active')
                    ->boolean(),
                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}
